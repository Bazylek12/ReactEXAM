const produkty = [
  {
    nazwa: "mleko",
    kategoria: "nabiał",
    produktSpozywczy: true,
  },
  {
    nazwa: "sałata",
    kategoria: "warzywa",
    produktSpozywczy: true,
  },
  {
    nazwa: "sezam",
    kategoria: "nasiona",
    produktSpozywczy: true,
  },
  {
    nazwa: "ser",
    kategoria: "nabiał",
    produktSpozywczy: true,
  },
  {
    nazwa: "młotek",
    kategoria: "narzędzia",
    produktSpozywczy: false,
  },
  {
    nazwa: "wieszak",
    kategoria: "inne",
    produktSpozywczy: false,
  },
  {
    nazwa: "mak",
    kategoria: "nasiona",
    produktSpozywczy: true,
  },
  {
    nazwa: "czajnik",
    kategoria: "inne",
    produktSpozywczy: false,
  },
  {
    nazwa: "pieczarki",
    kategoria: "warzywa",
    produktSpozywczy: true,
  },
];

export default produkty;
